If you read this you cracked the challange! :D
Great job! And have fun with the humble bundle book!

Link: https://www.humblebundle.com/?gift=m67EUEYdnfZpXY4A
Youtube: https://www.youtube.com/watch?v=dE-sN5MUUKs&hd=1